

myjobresult('tj1_0_20_5_5_6');
myjobresult('tj1_0_20_20_20_6');
myjobresult('tj1_0_20_20_20_12');
myjobresult('tj1_0_20_20_5_6');
myjobresult('tj1_0_20_5_20_12');
myjobresult('tj1_0_20_5_20_6');
myjobresult('tj1_0_20_5_5_12');
myjobresult('tj1_0_20_5_5_6');
myjobresult('tj1_1_40_20_5_12');

