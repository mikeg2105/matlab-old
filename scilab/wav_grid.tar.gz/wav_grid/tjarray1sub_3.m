myjobsubmit('tj1_1_40_20_5_12', 'iceberg');
myjobsubmit('tj1_0_20_5_20_6', 'iceberg');
myjobsubmit('tj1_0_20_5_20_12', 'iceberg');
myjobsubmit('tj1_0_20_5_5_6', 'iceberg');
myjobsubmit('tj1_0_20_5_5_12', 'iceberg');
myjobsubmit('tj1_0_20_20_20_6', 'iceberg');
myjobsubmit('tj1_0_20_20_20_12', 'iceberg');
myjobsubmit('tj1_0_20_20_5_6', 'iceberg');
exit;
