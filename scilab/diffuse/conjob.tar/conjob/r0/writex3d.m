//save xyz values
function [writex3d]=writex3d(sFilename, sDescription, sCreated, sRevised, sURL, sAuthor)

  schemaname='X3D PUBLIC ""http://www.web3d.org/specifications/x3d-3.0.dtd""'
  schemahyperlink='file:///www.web3d.org/TaskGroups/x3d/translation/x3d-3.0.dtd'
	fd=writexml(sFilename, schemaname, schemahyperlink)
	
  openxml(fd, 'X3D');
  
  writex3dheader(fd,sFilename, sDescription, sCreated, sRevised, sURL, sAuthor)
  openxml(fd, 'Scene');
 

  writex3d=fd  
  
endfunction

function closex3d(fd)

	closexmlelement(fd, 'Scene');
	closexmlelement(fd, 'X3D');
	mclose(fd)

endfunction




function writex3dheader(fd,sFilename, sDescription, sCreated, sRevised, sURL, sAuthor,)

	openxml(fd, 'head');
	
		//	<meta content="HelloWorld.x3d" name="filename"/>
		//<meta content="Simple X3D example" name="description"/>
		//<meta content="30 October 2000" name="created"/>
		//<meta content="6 March 2003" name="revised"/>
		//<meta content="Don Brutzman" name="author"/>
		//<meta content="http://www.web3d.org/TaskGroups/x3d/translation/examples/HelloWorld.x3d" name="url"/>
		//<meta content="X3D-Edit, http://www.web3d.org/TaskGroups/x3d/translation/README.X3D-Edit.html" name="generator"/>

	
	
     writex3dmeta(fd,sFilename,'filename');
  		 writex3dmeta(fd,sDescription,'description');
     writex3dmeta(fd,sCreated,'created');
     writex3dmeta(fd,sRevised,'revised');
     writex3dmeta(fd,sAuthor,'author');
     writex3dmeta(fd,sURL,'url');
   
   
	   closexmlelement(fd, 'head');
	
endfunction

function writex3dmeta(fd, scontent, sname)
    attrbs(1,1)='content'
    attrbs(2,1)='name'
    attrbs(1,2)=scontent
    attrbs(2,2)=sname
		openxmlelement(fd, 'meta', attrbs, 2)
		closexmlelement(fd, 'meta')
endfunction



function writex3dnavinfo(fd)
     //<NavigationInfo type="&quot;EXAMINE&quot; &quot;ANY&quot;"/>
    attrbs(1,1)='type'
    attrbs(1,2)='&quot;EXAMINE&quot; &quot;ANY&quot;'
    openxmlelement(fd, 'NavigationInfo', attrbs, 1)
	closexmlelement(fd, 'NavigationInfo')
endfunction

function writex3dviewpoint(fd, sDescription, orient, pos)
     //mfprintf(fd, 'Viewpoint {\n');
     //mfprintf(fd, 'description "hello, world!"\n');
     //mfprintf(fd, 'orientation 0 1 0 1.57\n');
     //mfprintf(fd, 'position 6 -1 0\n');
     //mfprintf(fd, '}\n');
  
     sOrient=msprintf('%f %f %f %f', orient(1), orient(2), orient(3), orient(4));
     sPos=msprintf('%f %f %f', pos(1),pos(2),pos(3));
     attrbs(1,1)='description'
     attrbs(2,1)='orientation'
     attrbs(3,1)='position'
     attrbs(1,2)=sDescription
     attrbs(3,2)=sPos 
     attrbs(2,2)=sOrient
     openxmlelement(fd, 'Viewpoint', attrbs, 3)
     closexmlelement(fd, 'Viewpoint')    
        
endfunction

//fd, selevmat,np1,np2, colvec, rotvec, translation, maxcolvec
function writex3dIndexedFaceSet(fd, selevmat,np1,np2, colvec, rotvec, translation, maxcolvec)
 
 scol=sprintf('%f %f %f',colvec(1),colvec(2),colvec(3));
   stran=sprintf('%f %f %f',translation(1),translation(2),translation(3));
   srot=sprintf('%f %f %f %f',rotvec(1),rotvec(2),rotvec(3),rotvec(4));
    matattributelist(1,2)=scol;
   matattributelist(1,1)='diffuseColor';   
   tattributelist(1,2)=srot;
   tattributelist(1,1)='rotation';
   tattributelist(2,2)=stran;
   tattributelist(2,1)='translation';

colattributelist(1,2)='noddy';
   colattributelist(1,1)='color';   
   
attributelist(1,2)='noddy';
   attributelist(1,1)='coordIndex';
 attributelist(2,2)='0.524';
   attributelist(2,1)='creaseAngle';
  attributelist(3,2)='true';
   attributelist(3,1)='solid';
 
   
      coattributelist(1,2)='noddy';
       coattributelist(1,1)='point';
       
       mprintf('Writing IFS \n');
       
       openxmlelement(fd,'Transform', tattributelist, 2);
     openxml(fd, 'Shape');
        openxml(fd, 'Appearance');
            openxmlelement(fd, 'Material', matattributelist, 1);
            closexmlelement(fd, 'Material');
        closexmlelement(fd, 'Appearance');
	
	
       openIFSelement(fd, 'IndexedFaceSet', selevmat,np1,np2,attributelist, 3);
       opencoordelement(fd, 'Coordinate',selevmat,np1,np2, coattributelist, 1);
       closexmlelement(fd, 'Coordinate');
       opencolorelement(fd, 'Color',selevmat,np1,np2, maxcolvec, colattributelist, 1);
       closexmlelement(fd, 'Color');
       closexmlelement(fd, 'IndexedFaceSet');
       
      closexmlelement(fd, 'Shape');
    closexmlelement(fd, 'Transform');    
       
       
endfunction

//attribute list is a list of lists one attrib is number of attributes
//Each list element is a triple of attribute name and attribute value

//Note See programming quote
//to get a double quote output in a string

function openIFSelement(fd, elementname, selevmat,np1, np2, attributelist, numattributes)

   mfprintf(fd, '<%s', elementname);
   for k=1:numattributes
     attrbname=attributelist(k,1);
     attrbvalue=attributelist(k,2);   
     if k==1
       mfprintf(fd, ' %s=""', attrbname);  
	for j=1:np2-1
	  for i=1:np1-1
	    ic1=i+((j-1)*np2)-1;
	    ic2=i+((j-1)*np2);
	    ic3=ic1+np1;
	    ic4=ic2+np1;
	    index=i+((j-1)*np2);
	    mfprintf(fd,' %d %d %d %d -1',ic1, ic2, ic4, ic3); 
	  end
	end 
       mfprintf(fd, '""');
     else
       mfprintf(fd, ' %s=""%s""', attrbname, attrbvalue)
     end  
   end
   mfprintf(fd, '>\n');


endfunction

function opencoordelement(fd, elementname, selevmat,np1, np2, attributelist, numattributes)

  mfprintf(fd, '<%s', elementname);
   for k=1:numattributes
     attrbname=attributelist(k,1);
     attrbvalue=attributelist(k,2);   
     if k==1
       mfprintf(fd, ' %s=""', attrbname);  
	for j=1:np2
	  for i=1:np1
            index=i+((j-1)*np2);
	    if index==1 then
	      mfprintf(fd, '%d %d %f',i, j, selevmat(i,j));
	    else
	      mfprintf(fd, ', %d %d %f',i, j, selevmat(i,j));
	    end
	    //mfprintf(fd, '%d %d %f \n', i, j, selevmat(i,j));
	  end
	end 
       mfprintf(fd, '""');
     else
       mfprintf(fd, ' %s=""%s""', attrbname, attrbvalue)
     end  
   end
   mfprintf(fd, '>\n');

endfunction

function opencolorelement(fd, elementname,selevmat,np1,np2, maxcolvec, attributelist, numattributes)

   mfprintf(fd, '<%s', elementname);
   for k=1:numattributes
     attrbname=attributelist(k,1);
     attrbvalue=attributelist(k,2);   
     if k==1
       mfprintf(fd, ' %s=""', attrbname);  
	for j=1:np2
	  for i=1:np1
	    index=i+((j-1)*np2);
	    colvec=getcolvec(selevmat(i,j),maxcolvec(1),maxcolvec(2));
	    if index==1 then
	      mfprintf(fd, '%f %f %f',colvec(1), colvec(2), colvec(3));
	    else
	      mfprintf(fd,', %f %f %f',colvec(1), colvec(2), colvec(3));
	    end
	  end
	end 
       mfprintf(fd, '""');
     else
       mfprintf(fd, ' %s=""%s""', attrbname, attrbvalue)
     end  
   end
   mfprintf(fd, '>\n');


endfunction


function [cvec]=getcolvec(val,maxval,minval)

	crange=zeros(2)
	cwid=(maxval-minval)/3;
	if cwid<=0 
	   cwid=1;
	end
	crange(1)=minval+cwid;
	crange(2)=minval+2*cwid;
	//diffuse colour vector
	colvec=zeros(3)
	
	
	//cycle through each element of the layer
   
	if val>crange(2)
	       colvec(1)=(val-crange(2))/cwid;
	       colvec(2)=0;
	       colvec(3)=0;
	elseif val>crange(1)
	       colvec(1)=0;
	       colvec(2)=(val-crange(1))/cwid;
	       colvec(3)=0;          
	else
	       colvec(1)=0;
	       colvec(2)=0;
	       colvec(3)=val/cwid;           
        end
	cvec=colvec;

endfunction


function writex3dElevationGrid(fd, selevvec, xdim, zdim, xspace, zspace, colvec, rotvec, translation)
  scol=sprintf('%f %f %f',colvec(1),colvec(2),colvec(3));
   stran=sprintf('%f %f %f',translation(1),translation(2),translation(3));
   srot=sprintf('%f %f %f %f',rotvec(1),rotvec(2),rotvec(3),rotvec(4));
    matattributelist(1,2)=scol;
   matattributelist(1,1)='diffuseColor';   
   attributelist(1,2)=srot;
   attributelist(1,1)='rotation';
   attributelist(2,2)=stran;
   attributelist(2,1)='translation';
   //elevattriblist(1,2)=3.14159;
   //elevattriblist(1,1)='creaseAngle';
   //elevattriblist(2,2)='false';
   //elevattriblist(2,1)='solid';
  // elevattriblist(3,2)=xdim;
  // elevattriblist(3,1)='xDimension';  
  //elevattriblist(4,2)=xspace;
  // elevattriblist(4,1)='xSpacing';
  // elevattriblist(5,2)=zdim;  
   //elevattriblist(5,1)='zDimension';
   //elevattriblist(6,2)=zspace;  
   // elevattriblist(6,1)='zSpacing';
  //elevattriblist(7,2)=selevvec;  
   // elevattriblist(7,1)='height';    
   //creaseAngle='3.14159' solid='false' xDimension='40' xSpacing='0.025' zDimension='40' zSpacing='0.025' height=
   printf('Writing elevattriblist\n');  
   openxmlelement(fd,'Transform', attributelist, 2);
     openxml(fd, 'Shape');
        openxml(fd, 'Appearance');
            openxmlelement(fd, 'Material', matattributelist, 1);
            closexmlelement(fd, 'Material');
        closexmlelement(fd, 'Appearance');
           writeelevgridelement(fd,3.141, 'false', xdim, xspace, zdim, zspace, selevvec);
	//openxmlelement(fd, 'ElevationGrid', elevattriblist, 7);
	//closexmlelement(fd, 'ElevationGrid');
     closexmlelement(fd, 'Shape');
    closexmlelement(fd, 'Transform');

endfunction

function writeelevgridelement(fd, fcrease, sbool, xdim, xspace, zdim, zspace, selevvec)
 //elevattriblist(1,2)=fcrease;
   //elevattriblist(1,1)='creaseAngle';
 //elevattriblist(2,2)=sbool;
   //elevattriblist(2,1)='solid';
   //elevattriblist(3,2)=xdim;
   //elevattriblist(3,1)='xDimension';  
 // elevattriblist(4,2)=xspace;
  // elevattriblist(4,1)='xSpacing';
  // elevattriblist(5,2)=zdim;  
  // elevattriblist(5,1)='zDimension';
  // elevattriblist(6,2)=zspace;  
   // elevattriblist(6,1)='zSpacing';
  //elevattriblist(7,2)=selevvec;  
   // elevattriblist(7,1)='height';    
   //creaseAngle='3.14159' solid='false' xDimension='40' xSpacing='0.025' zDimension='40' zSpacing='0.025' height=
   fcrease=0.275
   fprintf(fd, '<ElevationGrid ');
   fprintf(fd, 'creaseAngle=""%f""', fcrease);
   fprintf(fd, ' solid=""%s""', sbool);
   fprintf(fd, ' xDimension=""%f""', xdim);
   fprintf(fd, ' xSpacing=""%f""', xspace);
   fprintf(fd, ' zDimension=""%f""', zdim);
   fprintf(fd, ' zSpacing=""%f""', zspace);
   fprintf(fd, ' height=""%s""', selevvec);
   fprintf(fd,'>\n');
   fprintf(fd, '</ElevationGrid>');
   //openxmlelement(fd, 'ElevationGrid', elevattriblist, 7);
//	closexmlelement(fd, 'ElevationGrid');
endfunction

function writex3dColouredShape(fd, shapetype, shapeprops, colvec, rotvec, translation)



 
   
   scol=sprintf('%f %f %f',colvec(1),colvec(2),colvec(3));
   stran=sprintf('%f %f %f',translation(1),translation(2),translation(3));
   srot=sprintf('%f %f %f %f',rotvec(1),rotvec(2),rotvec(3),rotvec(4));
    matattributelist(1,2)=scol;
   matattributelist(1,1)='diffuseColor';   
   attributelist(1,2)=srot;
   attributelist(1,1)='rotation';
   attributelist(2,2)=stran;
   attributelist(2,1)='translation';
   openxmlelement(fd,'Transform', attributelist, 2);
     openxml(fd, 'Shape');
        openxml(fd, 'Appearance');
            openxmlelement(fd, 'Material', matattributelist, 1);
            closexmlelement(fd, 'Material');
        closexmlelement(fd, 'Appearance');
        
        
        //write the actual shape
        //normally do something clever with shape props
        if shapetype=='cone'
           openxml(fd, 'Cone');
           closexmlelement(fd, 'Cone');      
        end
        
        
 
     closexmlelement(fd, 'Shape');
   
   closexmlelement(fd, 'Transform');
   //use magnitude of concentration
   //to determine material colour
   

endfunction





