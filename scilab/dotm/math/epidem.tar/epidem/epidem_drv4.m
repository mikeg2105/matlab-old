
function [status]=fload()
	exec("//TIGGER/mike cygwin/proj/math/epidem_drv1");
	exec("//TIGGER/mike cygwin/proj/math/epidem_drv2");
	exec("//TIGGER/mike cygwin/proj/math/epidem_drv3");
	status=0
endfunction
